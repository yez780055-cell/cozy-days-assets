# Codex 任务：小饱日常（Cozy Days）安卓应用素材精细拆分与交付

你正在维护我的安卓 App「小饱日常 Cozy Days」，视觉主题是温暖的手绘蜡笔 + 柔和水彩、略带俏皮的粉色/奶油/薰衣草色系。请在当前项目里处理我提供的 `cozy_days_asset_handoff/` 素材包。先检查仓库技术栈（原生 Android XML/Compose/Flutter 等），再选择恰当的资源目录。请真正执行文件拆分与质量验收，不只给计划。

## 1. 输入文件
- `sources/00_original_ui_reference.png` 是页面布局和原视觉参考。
- `sources/01_paper_texture.png` 是米白纸张纹理。
- `sources/02_bedroom_background.png` 是粉色卧室头图背景。
- `sources/03_header_cats.png` 是顶部白猫+黑猫组合。
- `sources/04_empty_state_cats.png` 是空状态猫咪组合（不同姿态）。
- `sources/05_cat_books_sticker_sheet.png` 是黑猫、书本、文具合集。
- `sources/06_task_icons_sheet.png` 是电脑、扫帚、书、拉伸人物合集。
- `sources/07_decorations_sheet.png` 是胶带、蝴蝶结、樱桃、花等合集。
- `sources/08_stars_hearts_drops_sheet_a.png` 与 `09_stars_hearts_drops_sheet_b.png` 是符号参考图。
- `docs/ASSET_SPLIT_MANIFEST.csv` 给出具体必须输出的独立资源。逐行落实，不要漏掉。
- `docs/SOURCE_AUDIT.json` 记录真实源文件像素尺寸和背景透明情况。

## 2. 工作方式和保真要求
1. 保留 `sources/` 原文件不变；新文件统一写入 `output/`。
2. 按 manifest 的 visual_locator 拆分每一张素材；绝不能把整张贴纸表当单个控件插图。
3. 对相邻元素用合理裁切区域、连通域、边缘/颜色分割、蒙版与手工路径相结合。尤其是位于右侧的多个花和樱桃、左上胶带，要防止互相污染。
4. 对图中的灰白棋盘格进行真实去背景处理。注意灰白格可能是已经烘焙的像素，而不是图像查看器显示的透明底：必须检查 RGBA 的 alpha 分布和 RGB 像素。不可简单使用“去白”阈值损坏白猫、白色书页、白色花朵或眼部高光。遇到无法可靠分离时，输出高质量待修复清单和蒙版，不要伪称完成。
5. 真实 alpha: 对复杂插画以 PNG RGBA 为主；边缘进行去杂色/alpha matte 校正，保护手绘毛边和低不透明度水彩纹理。不要留下黑灰色阴影或重复的棋盘花纹。
6. 每张图按内容裁剪到紧边框，并留 3%–8% 透明安全留白；避免切掉猫须、猫耳、书签、裙裤、扫帚毛、樱桃梗及周围小笔触。
7. 顶部猫组合与空状态猫组合分别保留完整成品。不得用同一张图片代替两种姿态。原顶部猫可以保留其自带粉色被褥，注意合成到背景时不要让被褥重复得突兀。
8. 卧室背景是一个横向插画而安卓竖屏头图区可能不同：采用等比 cover + 指定焦点，绝不要被拉伸；必要时另做适配用蒙版/渐隐边缘，而不是无约束变形。
9. 检查米白纸纹实际无缝程度：做 2×2 和 3×3 平铺接缝预览。如原图边缘不无缝，修复为 seamless tile，保留纸张颗粒和微妙色差，不能出现十字边界。
10. 对星星、爱心、水滴，制作真正的 SVG：以手工矢量 path、fill、stroke、渐变表达，viewBox 合理，线条可随尺寸缩放，输出合理的实心/描边变体。不要把位图嵌进 SVG 作为伪矢量。源图可作为临摹参考，不要求复刻随机水彩噪点。
11. 不要把任务卡片、标签、勾选框、加号、底部导航、真实文字、日期等 UI 结构截图切成 PNG。这些应由实际 UI 组件绘制；图标仅为图片装饰。
12. 文件小写 snake_case，避免中文名与空格；输出文件与 manifest 名字一一对应。相似变体加 `_01`、`_02` 等明确编号。

## 3. 输出目录建议
```
output/
  raster/backgrounds/
  raster/characters/
  raster/stationery/
  raster/tasks/
  raster/decor/
  vectors/symbols/
  previews/
  reports/
```
将 `output/raster/` 下合格 PNG/WebP 接到项目最适合的 Android assets/drawable 路径；SVG 如项目不支持运行时 SVG，请转换成 Android VectorDrawable 或通过受支持的构建工具引入，仍保留原 SVG 源文件。

## 4. 必须提供的完整交付物
- manifest 中每一条目标素材的独立导出文件（或明确列入待修复）；另保留合成角色图。
- `previews/contact_sheet_light.png` 和 `previews/contact_sheet_dark.png`：分别展示所有素材在浅/深背景下的质量。
- `previews/background_tile_3x3.png`：纸张纹理平铺接缝检测。
- `reports/asset_inventory.csv`：文件名、源、尺寸、alpha状态、状态(ready/needs_review/blocked)、用途、备注。
- `reports/qa.md`：批量透明度/尺寸/裁切/矢量合法性检查、未解决项目和修复建议。
- `reports/android_integration.md`：在当前安卓技术栈中各类素材的引用方式、建议尺寸与缩放规则，尤其是顶部卧室背景和猫咪叠层。
- 如已有 Android 工程，接好可用资源并提供至少一个真实页面引用示例；不要在未验证时宣称所有资源已集成。

## 5. 校验办法
- 对每个有透明要求的 PNG：确认含 alpha，确认画面四角大部分透明，在白色/深灰/粉色背景的合成预览均无格子残留。
- 复杂插画完整，背景确实透明，颜色与原稿接近，素材之间无串图。
- 符号 SVG 可以在至少 24、48、96 px 导出，线条保持自然且没有锯齿。
- 平铺纹理接缝可接受，3×3 预览没有明显网格线。
- 原始来源保持不变，自动裁切的任何失误可追溯回来源文件和蒙版。

请现在实际检查文件、实施拆分、处理透明背景并输出可直接提交到仓库的资源及质量报告。优先保证质量，不要在存在棋盘背景时把导出标记成 ready。
